/* =========================================================
   modal.js — generic modal open/close
   ========================================================= */
const Modal = {
  el: null, backdrop: null,
  init(){
    this.el = document.getElementById('modal');
    this.backdrop = document.getElementById('modal-backdrop');
    this.backdrop.addEventListener('click', (e) => {
      if(e.target === this.backdrop) this.close();
    });
    document.addEventListener('keydown', (e) => {
      if(e.key === 'Escape') this.close();
    });
  },
  open(html, onMount){
    this.el.innerHTML = html;
    this.backdrop.hidden = false;
    if(onMount) onMount(this.el);
    const firstInput = this.el.querySelector('input,select,textarea');
    if(firstInput) setTimeout(()=>firstInput.focus(), 50);
  },
  close(){
    this.backdrop.hidden = true;
    this.el.innerHTML = '';
  }
};
