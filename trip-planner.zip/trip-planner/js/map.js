/* =========================================================
   map.js — Leaflet map, OSM geocoding & attraction search
   ========================================================= */
const MapModule = (() => {
  let map = null;
  let markersLayer = null;
  let destMarker = null;

  function ensureMap(){
    if(map) { setTimeout(()=>map.invalidateSize(), 80); return map; }
    map = L.map('leaflet-map', {zoomControl:true}).setView([20,0], 2);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      maxZoom:19
    }).addTo(map);
    markersLayer = L.layerGroup().addTo(map);
    return map;
  }

  function clearMarkers(){
    if(markersLayer) markersLayer.clearLayers();
  }

  function setCenter(lat, lon, zoom=13){
    ensureMap();
    map.setView([lat, lon], zoom);
    if(destMarker) map.removeLayer(destMarker);
    destMarker = L.marker([lat, lon], {
      icon: L.divIcon({className:'', html:'<div style="font-size:26px; transform:translate(-8px,-22px)">📍</div>'})
    }).addTo(map);
  }

  function addAttractionMarker(item, onAdd){
    ensureMap();
    const m = L.marker([item.lat, item.lon]).addTo(markersLayer);
    const popupHtml = `
      <div style="font-family:Inter,sans-serif">
        <strong>${esc(item.name)}</strong><br>
        <span style="font-size:.78rem;color:var(--ink-dim)">${esc(item.type||'')}</span><br>
        <button class="btn btn-sm popup-add-btn" data-action="add">+ Add to itinerary</button>
      </div>`;
    m.bindPopup(popupHtml);
    m.on('popupopen', (e) => {
      const btn = e.popup._contentNode.querySelector('[data-action="add"]');
      if(btn) btn.addEventListener('click', () => onAdd(item));
    });
    return m;
  }

  // Forward geocode a place name -> {lat, lon, displayName}
  async function geocode(query){
    const url = `https://nominatim.openstreetmap.org/search?format=json&limit=1&q=${encodeURIComponent(query)}`;
    const res = await fetch(url, {headers:{'Accept-Language':'en'}});
    if(!res.ok) throw new Error('Geocoding failed');
    const data = await res.json();
    if(!data.length) return null;
    return {lat: parseFloat(data[0].lat), lon: parseFloat(data[0].lon), displayName: data[0].display_name};
  }

  // Search attractions near a point using Overpass API (OSM tourism/leisure/amenity tags)
  async function searchAttractions(lat, lon, keyword, radius=8000){
    const kw = keyword.trim().toLowerCase();
    const query = `
      [out:json][timeout:25];
      (
        node["tourism"](around:${radius},${lat},${lon});
        node["leisure"~"park|garden"](around:${radius},${lat},${lon});
        node["amenity"~"cafe|restaurant|bar|museum"](around:${radius},${lat},${lon});
      );
      out center 40;
    `;
    const res = await fetch('https://overpass-api.de/api/interpreter', {
      method:'POST',
      body: 'data=' + encodeURIComponent(query)
    });
    if(!res.ok) throw new Error('Overpass query failed');
    const data = await res.json();
    let results = (data.elements || [])
      .filter(el => el.tags && (el.tags.name))
      .map(el => ({
        id: 'osm_' + el.id,
        name: el.tags.name,
        type: el.tags.tourism || el.tags.leisure || el.tags.amenity || 'place',
        lat: el.lat, lon: el.lon
      }));
    if(kw){
      results = results.filter(r =>
        r.name.toLowerCase().includes(kw) || r.type.toLowerCase().includes(kw)
      );
    }
    // de-dupe by name
    const seen = new Set();
    results = results.filter(r => seen.has(r.name) ? false : (seen.add(r.name), true));
    return results.slice(0, 30);
  }

  return { ensureMap, clearMarkers, setCenter, addAttractionMarker, geocode, searchAttractions };
})();
