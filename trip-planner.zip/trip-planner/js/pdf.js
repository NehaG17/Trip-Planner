/* =========================================================
   pdf.js — export itinerary as a PDF using jsPDF
   ========================================================= */
const PdfModule = (() => {
  function exportItinerary(trip){
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({unit:'pt', format:'a4'});
    const marginX = 48;
    let y = 56;
    const pageH = doc.internal.pageSize.getHeight();
    const pageW = doc.internal.pageSize.getWidth();

    doc.setFont('helvetica','bold');
    doc.setFontSize(20);
    doc.setTextColor(20,30,28);
    doc.text(trip.name || 'Trip Itinerary', marginX, y);
    y += 22;

    doc.setFont('helvetica','normal');
    doc.setFontSize(11);
    doc.setTextColor(90,95,90);
    doc.text(`${trip.destination || ''}  •  ${dateRange(trip.startDate, trip.endDate)}`, marginX, y);
    y += 26;

    doc.setDrawColor(210,200,180);
    doc.line(marginX, y, pageW - marginX, y);
    y += 22;

    if(!trip.days.length){
      doc.text('No itinerary items yet.', marginX, y);
    }

    trip.days.forEach((day, idx) => {
      if(y > pageH - 90){ doc.addPage(); y = 56; }
      doc.setFont('helvetica','bold');
      doc.setFontSize(14);
      doc.setTextColor(190,120,40);
      doc.text(`Day ${idx+1} — ${day.label || fmtDateShort(day.date) || ''}`, marginX, y);
      y += 18;

      if(!day.items.length){
        doc.setFont('helvetica','italic');
        doc.setFontSize(10);
        doc.setTextColor(120,120,120);
        doc.text('No activities planned', marginX + 12, y);
        y += 16;
      }

      day.items.forEach(item => {
        if(y > pageH - 70){ doc.addPage(); y = 56; }
        doc.setFont('helvetica','bold');
        doc.setFontSize(11);
        doc.setTextColor(20,30,28);
        const timeStr = item.time ? `${item.time} — ` : '';
        doc.text(`${timeStr}${item.title}`, marginX + 12, y);
        y += 14;
        if(item.desc){
          doc.setFont('helvetica','normal');
          doc.setFontSize(9.5);
          doc.setTextColor(110,110,110);
          const lines = doc.splitTextToSize(item.desc, pageW - marginX*2 - 24);
          doc.text(lines, marginX + 14, y);
          y += lines.length * 12 + 4;
        }
        y += 4;
      });
      y += 10;
    });

    doc.save(`${(trip.name || 'trip').replace(/\s+/g,'_')}_itinerary.pdf`);
  }

  return { exportItinerary };
})();
