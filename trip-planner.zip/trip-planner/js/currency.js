/* =========================================================
   currency.js — free, no-key FX rates via Frankfurter API
   ========================================================= */
const CurrencyModule = (() => {
  let cache = null; // {base, rates, date}

  const COMMON = ['USD','EUR','GBP','JPY','INR','AUD','CAD','CHF','CNY','SGD','AED','THB','MXN','ZAR','BRL'];

  async function loadRates(base='USD'){
    const url = `https://api.frankfurter.app/latest?from=${base}`;
    const res = await fetch(url);
    if(!res.ok) throw new Error('Currency fetch failed');
    const data = await res.json();
    cache = {base: data.base, rates: data.rates, date: data.date};
    return cache;
  }

  async function convert(amount, from, to){
    if(from === to) return {value: amount, date: 'today'};
    if(!cache || cache.base !== from){
      await loadRates(from);
    }
    const rate = cache.rates[to];
    if(rate === undefined) throw new Error('Rate not available for ' + to);
    return {value: amount * rate, date: cache.date, rate};
  }

  return { loadRates, convert, COMMON };
})();
