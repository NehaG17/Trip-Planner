/* =========================================================
   weather.js — free, no-key weather via Open-Meteo
   ========================================================= */
const WeatherModule = (() => {
  const WMO = {
    0:'☀️ Clear sky', 1:'🌤️ Mostly clear', 2:'⛅ Partly cloudy', 3:'☁️ Overcast',
    45:'🌫️ Fog', 48:'🌫️ Rime fog', 51:'🌦️ Light drizzle', 53:'🌦️ Drizzle', 55:'🌧️ Dense drizzle',
    61:'🌧️ Light rain', 63:'🌧️ Rain', 65:'🌧️ Heavy rain', 71:'🌨️ Light snow', 73:'🌨️ Snow',
    75:'❄️ Heavy snow', 80:'🌦️ Rain showers', 81:'🌧️ Rain showers', 82:'⛈️ Violent showers',
    95:'⛈️ Thunderstorm', 96:'⛈️ Thunderstorm w/ hail', 99:'⛈️ Severe thunderstorm'
  };
  function describe(code){ return WMO[code] || '🌡️ Unknown'; }

  async function forecast(lat, lon){
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}` +
      `&daily=weathercode,temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=10`;
    const res = await fetch(url);
    if(!res.ok) throw new Error('Weather fetch failed');
    const data = await res.json();
    const days = data.daily.time.map((date, i) => ({
      date,
      code: data.daily.weathercode[i],
      max: data.daily.temperature_2m_max[i],
      min: data.daily.temperature_2m_min[i]
    }));
    return days;
  }

  return { forecast, describe };
})();
