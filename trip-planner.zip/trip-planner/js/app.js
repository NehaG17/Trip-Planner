/* =========================================================
   app.js — main application controller
   ========================================================= */
const App = {
  currentView: 'dashboard',
  currentTripId: null,

  init(){
    Modal.init();
    this.applyTheme(Store.getTheme());
    this.bindNav();
    this.bindThemeToggle();
    this.bindGlobalButtons();
    this.route('dashboard');
  },

  /* ---------------- THEME ---------------- */
  applyTheme(theme){
    document.body.dataset.theme = theme;
    Store.setTheme(theme);
    const isDark = theme === 'dark';
    document.getElementById('theme-icon').textContent = isDark ? '☀' : '☾';
    document.getElementById('theme-label').textContent = isDark ? 'Light mode' : 'Dark mode';
    document.getElementById('topbar-theme-btn').textContent = isDark ? '☀' : '☾';
  },
  bindThemeToggle(){
    const toggle = () => {
      const next = document.body.dataset.theme === 'dark' ? 'light' : 'dark';
      this.applyTheme(next);
    };
    document.getElementById('theme-toggle').addEventListener('click', toggle);
    document.getElementById('topbar-theme-btn').addEventListener('click', toggle);
  },

  /* ---------------- NAV / ROUTING ---------------- */
  bindNav(){
    document.querySelectorAll('.nav-item').forEach(btn => {
      btn.addEventListener('click', () => {
        this.route(btn.dataset.view);
        this.closeMobileNav();
      });
    });
    document.getElementById('menu-btn').addEventListener('click', () => this.openMobileNav());
    document.getElementById('nav-scrim').addEventListener('click', () => this.closeMobileNav());
  },
  openMobileNav(){
    document.getElementById('sidenav').classList.add('open');
    document.getElementById('nav-scrim').classList.add('show');
  },
  closeMobileNav(){
    document.getElementById('sidenav').classList.remove('open');
    document.getElementById('nav-scrim').classList.remove('show');
  },

  tripViews: ['overview','itinerary','map','budget','packing','weather','currency'],

  route(view){
    if(this.tripViews.includes(view) && !this.currentTripId){
      Toast.show('Select a trip first');
      view = 'trips';
    }
    this.currentView = view;
    document.querySelectorAll('.view').forEach(v => v.hidden = true);
    const target = document.getElementById('view-' + view);
    if(target) target.hidden = false;

    document.querySelectorAll('.nav-item').forEach(b => b.classList.toggle('active', b.dataset.view === view));
    const titleMap = {dashboard:'Dashboard', trips:'My Trips', overview:'Overview', itinerary:'Itinerary',
      map:'Map & Attractions', budget:'Budget & Split', packing:'Packing List', weather:'Weather', currency:'Currency'};
    document.getElementById('topbar-title').textContent = titleMap[view] || 'Waypoint';

    this.renderView(view);
  },

  renderView(view){
    switch(view){
      case 'dashboard': this.renderDashboard(); break;
      case 'trips': this.renderTripsList(); break;
      case 'overview': this.renderOverview(); break;
      case 'itinerary': this.renderItinerary(); break;
      case 'map': this.renderMap(); break;
      case 'budget': this.renderBudget(); break;
      case 'packing': this.renderPacking(); break;
      case 'weather': this.renderWeather(); break;
      case 'currency': this.renderCurrency(); break;
    }
  },

  bindGlobalButtons(){
    document.getElementById('dash-new-trip').addEventListener('click', () => this.openTripForm());
    document.getElementById('trips-new-trip').addEventListener('click', () => this.openTripForm());
  },

  /* ---------------- TRIP HELPERS ---------------- */
  getCurrentTrip(){ return this.currentTripId ? Store.get(this.currentTripId) : null; },
  selectTrip(id){
    this.currentTripId = id;
    document.getElementById('trip-context-divider').hidden = false;
    document.getElementById('trip-context-nav').hidden = false;
    this.route('overview');
  },
  showTripContext(show){
    document.getElementById('trip-context-divider').hidden = !show;
    document.getElementById('trip-context-nav').hidden = !show;
  },

  /* ================= DASHBOARD ================= */
  renderDashboard(){
    const trips = Store.getAll();
    this.showTripContext(!!this.currentTripId);

    const totalTrips = trips.length;
    const totalDays = trips.reduce((s,t) => s + tripDaysCount(t), 0);
    const totalExpenses = trips.reduce((s,t) => s + t.expenses.reduce((a,e)=>a+Number(e.amount||0),0), 0);
    const upcoming = trips.filter(t => t.startDate && new Date(t.startDate) >= new Date(new Date().toDateString())).length;

    document.getElementById('stat-row').innerHTML = `
      <div class="stat-card"><div class="num">${totalTrips}</div><div class="label">Total trips</div></div>
      <div class="stat-card"><div class="num">${upcoming}</div><div class="label">Upcoming trips</div></div>
      <div class="stat-card"><div class="num">${totalDays}</div><div class="label">Days planned</div></div>
      <div class="stat-card"><div class="num">${money(totalExpenses,'USD')}</div><div class="label">Tracked expenses</div></div>
    `;

    const list = document.getElementById('dash-trip-list');
    if(!trips.length){
      list.innerHTML = `<div class="empty-state"><div class="big">🧭</div><p>No trips yet — start your first journey.</p></div>`;
    }else{
      list.innerHTML = trips.slice(-4).reverse().map(t => this.boardingPassHtml(t)).join('');
      list.querySelectorAll('.boarding-pass').forEach(el => {
        el.addEventListener('click', () => this.selectTrip(el.dataset.id));
      });
    }

    const upcomingItems = [];
    trips.forEach(t => {
      t.days.forEach(d => d.items.forEach(it => upcomingItems.push({...it, tripName:t.name, date:d.date, dateLabel:d.label})));
    });
    upcomingItems.sort((a,b) => (a.date||'').localeCompare(b.date||''));
    const upcomingEl = document.getElementById('dash-upcoming');
    const future = upcomingItems.filter(i => !i.date || new Date(i.date) >= new Date(new Date().toDateString())).slice(0,6);
    upcomingEl.innerHTML = future.length ? future.map(i => `
      <div class="upcoming-item">
        <div class="upcoming-date">${i.dateLabel || fmtDateShort(i.date) || '—'}</div>
        <div>
          <div class="upcoming-title">${esc(i.title)}</div>
          <div class="upcoming-sub">${esc(i.tripName)}${i.time ? ' · ' + i.time : ''}</div>
        </div>
      </div>`).join('') : `<div class="empty-state"><p>No upcoming activities scheduled.</p></div>`;
  },

  boardingPassHtml(t){
    const code = (t.destination || t.name || 'TRP').replace(/[^A-Za-z]/g,'').slice(0,3).toUpperCase() || 'TRP';
    return `
      <div class="boarding-pass" data-id="${t.id}">
        <div class="bp-main">
          <div class="bp-route">${esc(t.destination || 'Destination TBD')}</div>
          <div class="bp-name">${esc(t.name)}</div>
          <div class="bp-dates">${dateRange(t.startDate, t.endDate)}</div>
          <div class="bp-meta">
            <span>👥 ${t.travelers.length}</span>
            <span>▤ ${tripDaysCount(t)} days</span>
            <span>$ ${money(t.expenses.reduce((a,e)=>a+Number(e.amount||0),0), t.currency)}</span>
          </div>
        </div>
        <div class="bp-stub"><span class="bp-code">${code}</span></div>
      </div>`;
  },

  /* ================= TRIPS LIST ================= */
  renderTripsList(){
    const trips = Store.getAll();
    const grid = document.getElementById('trip-card-grid');
    if(!trips.length){
      grid.innerHTML = `<div class="empty-state"><div class="big">🗺️</div><p>No trips yet. Click "+ New trip" to begin planning.</p></div>`;
      return;
    }
    grid.innerHTML = trips.slice().reverse().map(t => this.boardingPassHtml(t)).join('');
    grid.querySelectorAll('.boarding-pass').forEach(el => {
      el.addEventListener('click', () => this.selectTrip(el.dataset.id));
    });
  },

  openTripForm(existing=null){
    const isEdit = !!existing;
    Modal.open(`
      <h2>${isEdit ? 'Edit trip' : 'New trip'}</h2>
      <form id="trip-form">
        <div class="field"><label>Trip name</label><input required id="f-name" value="${existing ? esc(existing.name) : ''}" placeholder="Summer in Japan"></div>
        <div class="field"><label>Destination</label><input required id="f-dest" value="${existing ? esc(existing.destination) : ''}" placeholder="Tokyo, Japan"></div>
        <div class="field-row">
          <div class="field"><label>Start date</label><input type="date" id="f-start" value="${existing ? existing.startDate||'' : ''}"></div>
          <div class="field"><label>End date</label><input type="date" id="f-end" value="${existing ? existing.endDate||'' : ''}"></div>
        </div>
        <div class="field"><label>Trip currency</label>
          <select id="f-currency">${CurrencyModule.COMMON.map(c=>`<option value="${c}" ${existing&&existing.currency===c?'selected':''}>${c}</option>`).join('')}</select>
        </div>
        <div class="modal-actions">
          <button type="button" class="btn btn-ghost" id="trip-cancel">Cancel</button>
          <button type="submit" class="btn btn-primary">${isEdit?'Save changes':'Create trip'}</button>
        </div>
      </form>
    `, (el) => {
      el.querySelector('#trip-cancel').addEventListener('click', () => Modal.close());
      el.querySelector('#trip-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const name = el.querySelector('#f-name').value.trim();
        const destination = el.querySelector('#f-dest').value.trim();
        const startDate = el.querySelector('#f-start').value;
        const endDate = el.querySelector('#f-end').value;
        const currency = el.querySelector('#f-currency').value;
        if(!name || !destination) return;

        const submitBtn = el.querySelector('button[type=submit]');
        submitBtn.textContent = 'Locating…'; submitBtn.disabled = true;
        let coords = {lat:null, lon:null};
        try{
          const geo = await MapModule.geocode(destination);
          if(geo) coords = {lat:geo.lat, lon:geo.lon};
        }catch(err){ console.warn('Geocode failed', err); }

        if(isEdit){
          Object.assign(existing, {name, destination, startDate, endDate, currency, lat:coords.lat ?? existing.lat, lon:coords.lon ?? existing.lon});
          Store.save(existing);
          Toast.show('Trip updated');
        }else{
          const trip = newTrip({name, destination, lat:coords.lat, lon:coords.lon, startDate, endDate});
          trip.currency = currency;
          if(startDate && endDate){
            trip.days = daysBetween(startDate, endDate).map(d => ({id:uid('day'), date:d, label:'', items:[]}));
          }
          Store.save(trip);
          this.currentTripId = trip.id;
          Toast.show('Trip created 🎉');
        }
        Modal.close();
        if(isEdit){ this.renderOverview(); } else { this.selectTrip(this.currentTripId); }
        this.renderDashboard();
      });
    });
  },

  /* ================= OVERVIEW ================= */
  renderOverview(){
    const trip = this.getCurrentTrip();
    if(!trip) return this.route('trips');
    document.getElementById('ov-name').textContent = trip.name;
    document.getElementById('ov-destination').textContent = trip.destination;
    document.getElementById('ov-dates').textContent = dateRange(trip.startDate, trip.endDate);
    document.getElementById('ov-notes').value = trip.notes || '';

    document.getElementById('ov-travelers').innerHTML = trip.travelers.map(t => `
      <div class="chip"><span class="avatar">${initials(t.name)}</span>${esc(t.name)}
        ${trip.travelers.length > 1 ? `<button data-id="${t.id}" class="rm-trav" title="Remove">×</button>` : ''}
      </div>`).join('');

    const totalSpent = trip.expenses.reduce((a,e)=>a+Number(e.amount||0),0);
    const packedCount = trip.packing.filter(p=>p.checked).length;
    document.getElementById('ov-stats').innerHTML = `
      <div class="stat-card"><div class="num">${tripDaysCount(trip)}</div><div class="label">Days</div></div>
      <div class="stat-card"><div class="num">${trip.travelers.length}</div><div class="label">Travelers</div></div>
      <div class="stat-card"><div class="num">${money(totalSpent, trip.currency)}</div><div class="label">Total spent</div></div>
      <div class="stat-card"><div class="num">${packedCount}/${trip.packing.length}</div><div class="label">Packed</div></div>
    `;

    document.getElementById('ov-notes').oninput = debounce(() => {
      trip.notes = document.getElementById('ov-notes').value;
      Store.save(trip);
    }, 500);

    document.getElementById('ov-edit').onclick = () => this.openTripForm(trip);
    document.getElementById('ov-delete').onclick = () => {
      if(confirm(`Delete "${trip.name}"? This cannot be undone.`)){
        Store.remove(trip.id);
        this.currentTripId = null;
        this.showTripContext(false);
        Toast.show('Trip deleted');
        this.route('trips');
      }
    };
    document.getElementById('ov-add-traveler').onclick = () => {
      const name = prompt('Traveler name:');
      if(name && name.trim()){
        trip.travelers.push({id: uid('trav'), name: name.trim()});
        Store.save(trip);
        this.renderOverview();
      }
    };
    document.querySelectorAll('.rm-trav').forEach(btn => {
      btn.onclick = () => {
        trip.travelers = trip.travelers.filter(t => t.id !== btn.dataset.id);
        trip.expenses.forEach(e => { e.splitWith = e.splitWith.filter(id => id !== btn.dataset.id); });
        Store.save(trip);
        this.renderOverview();
      };
    });
  },

  /* ================= ITINERARY ================= */
  renderItinerary(){
    const trip = this.getCurrentTrip();
    if(!trip) return this.route('trips');
    const container = document.getElementById('itin-days');

    if(!trip.days.length){
      container.innerHTML = `<div class="empty-state"><div class="big">▤</div><p>No days yet — add your first day to start building the itinerary.</p></div>`;
    }else{
      container.innerHTML = trip.days.map((day, idx) => `
        <div class="itin-day" data-day-id="${day.id}">
          <div class="itin-day-head">
            <div class="itin-day-title">
              <span class="itin-day-badge">DAY ${idx+1}</span>
              <input class="day-label" value="${esc(day.label || (day.date ? fmtDateShort(day.date) : 'Untitled day'))}" data-day-id="${day.id}">
            </div>
            <button class="btn btn-sm rm-day" data-day-id="${day.id}">Remove day</button>
          </div>
          <div class="itin-items" data-day-id="${day.id}">
            ${day.items.map(item => this.itinItemHtml(item)).join('')}
          </div>
          <div class="itin-day-foot">
            <button class="add-item-link" data-day-id="${day.id}">+ Add activity</button>
          </div>
        </div>
      `).join('');
    }

    // bind sortable per day
    container.querySelectorAll('.itin-items').forEach(list => {
      new Sortable(list, {
        group: 'itinerary',
        animation: 180,
        handle: '.drag-handle',
        ghostClass: 'sortable-ghost',
        chosenClass: 'sortable-chosen',
        onEnd: () => this.persistItineraryOrder(trip)
      });
    });

    container.querySelectorAll('.day-label').forEach(inp => {
      inp.addEventListener('input', debounce(() => {
        const day = trip.days.find(d => d.id === inp.dataset.dayId);
        if(day){ day.label = inp.value; Store.save(trip); }
      }, 400));
    });
    container.querySelectorAll('.rm-day').forEach(btn => {
      btn.addEventListener('click', () => {
        trip.days = trip.days.filter(d => d.id !== btn.dataset.dayId);
        Store.save(trip);
        this.renderItinerary();
      });
    });
    container.querySelectorAll('.add-item-link').forEach(btn => {
      btn.addEventListener('click', () => this.openItemForm(trip, btn.dataset.dayId));
    });
    container.querySelectorAll('.it-edit').forEach(btn => {
      btn.addEventListener('click', () => this.openItemForm(trip, btn.dataset.dayId, btn.dataset.itemId));
    });
    container.querySelectorAll('.it-del').forEach(btn => {
      btn.addEventListener('click', () => {
        const day = trip.days.find(d => d.id === btn.dataset.dayId);
        day.items = day.items.filter(i => i.id !== btn.dataset.itemId);
        Store.save(trip);
        this.renderItinerary();
      });
    });

    document.getElementById('itin-add-day').onclick = () => {
      trip.days.push({id: uid('day'), date:'', label:`Day ${trip.days.length+1}`, items:[]});
      Store.save(trip);
      this.renderItinerary();
    };
    document.getElementById('itin-export-pdf').onclick = () => {
      PdfModule.exportItinerary(trip);
      Toast.show('PDF exported');
    };
  },

  itinItemHtml(item){
    return `
      <div class="itin-item" data-item-id="${item.id}">
        <span class="drag-handle">⠿</span>
        ${item.time ? `<span class="it-time">${esc(item.time)}</span>` : ''}
        <div class="it-body">
          <div class="it-title">${esc(item.title)}</div>
          ${item.desc ? `<div class="it-desc">${esc(item.desc)}</div>` : ''}
        </div>
        <div class="it-actions">
          <button class="it-edit" data-day-id="${item.dayId}" data-item-id="${item.id}" title="Edit">✎</button>
          <button class="it-del" data-day-id="${item.dayId}" data-item-id="${item.id}" title="Remove">🗑</button>
        </div>
      </div>`;
  },

  persistItineraryOrder(trip){
    document.querySelectorAll('#itin-days .itin-items').forEach(list => {
      const dayId = list.dataset.dayId;
      const day = trip.days.find(d => d.id === dayId);
      if(!day) return;
      const ids = Array.from(list.children).map(el => el.dataset.itemId);
      const allItems = trip.days.flatMap(d => d.items);
      day.items = ids.map(id => {
        const it = allItems.find(i => i.id === id);
        if(it) it.dayId = dayId;
        return it;
      }).filter(Boolean);
    });
    // remove duplicates across days (item moved)
    const seenIds = new Set();
    trip.days.forEach(day => {
      day.items = day.items.filter(it => {
        if(seenIds.has(it.id)) return false;
        seenIds.add(it.id);
        return true;
      });
    });
    Store.save(trip);
  },

  openItemForm(trip, dayId, itemId=null){
    const day = trip.days.find(d => d.id === dayId);
    const existing = itemId ? day.items.find(i => i.id === itemId) : null;
    Modal.open(`
      <h2>${existing ? 'Edit activity' : 'Add activity'}</h2>
      <form id="item-form">
        <div class="field"><label>Title</label><input required id="i-title" value="${existing ? esc(existing.title) : ''}" placeholder="Visit the Senso-ji Temple"></div>
        <div class="field"><label>Time</label><input type="time" id="i-time" value="${existing ? existing.time||'' : ''}"></div>
        <div class="field"><label>Notes</label><textarea id="i-desc" placeholder="Address, tickets, reminders…">${existing ? esc(existing.desc||'') : ''}</textarea></div>
        <div class="modal-actions">
          <button type="button" class="btn btn-ghost" id="item-cancel">Cancel</button>
          <button type="submit" class="btn btn-primary">${existing ? 'Save' : 'Add'}</button>
        </div>
      </form>
    `, (el) => {
      el.querySelector('#item-cancel').addEventListener('click', () => Modal.close());
      el.querySelector('#item-form').addEventListener('submit', (e) => {
        e.preventDefault();
        const title = el.querySelector('#i-title').value.trim();
        if(!title) return;
        const time = el.querySelector('#i-time').value;
        const desc = el.querySelector('#i-desc').value.trim();
        if(existing){
          Object.assign(existing, {title, time, desc});
        }else{
          day.items.push({id: uid('item'), dayId, title, time, desc, lat:null, lon:null});
        }
        day.items.sort((a,b) => (a.time||'99:99').localeCompare(b.time||'99:99'));
        Store.save(trip);
        Modal.close();
        this.renderItinerary();
      });
    });
  },

  /* ================= MAP ================= */
  renderMap(){
    const trip = this.getCurrentTrip();
    if(!trip) return this.route('trips');
    MapModule.ensureMap();
    MapModule.clearMarkers();
    document.getElementById('attraction-results').innerHTML = '';
    document.getElementById('attraction-search').value = '';

    if(trip.lat && trip.lon){
      MapModule.setCenter(trip.lat, trip.lon, 13);
    }

    const doSearch = async () => {
      if(!trip.lat || !trip.lon){
        Toast.show('Set a destination with valid location first (edit trip).');
        return;
      }
      const kw = document.getElementById('attraction-search').value;
      const resultsEl = document.getElementById('attraction-results');
      resultsEl.innerHTML = `<p class="muted small">Searching OpenStreetMap…</p>`;
      MapModule.clearMarkers();
      try{
        const results = await MapModule.searchAttractions(trip.lat, trip.lon, kw);
        if(!results.length){
          resultsEl.innerHTML = `<p class="muted small">No attractions found. Try a different keyword.</p>`;
          return;
        }
        resultsEl.innerHTML = results.map(r => `
          <div class="attraction-card" data-id="${r.id}">
            <div class="a-name">${esc(r.name)}</div>
            <div class="a-type">${esc(r.type)}</div>
            <button class="btn btn-sm a-add" data-id="${r.id}">+ Add to itinerary</button>
          </div>`).join('');
        results.forEach(r => {
          MapModule.addAttractionMarker(r, (item) => this.addAttractionToItinerary(trip, item));
        });
        resultsEl.querySelectorAll('.attraction-card').forEach(card => {
          card.addEventListener('click', (e) => {
            if(e.target.classList.contains('a-add')) return;
            const r = results.find(x => x.id === card.dataset.id);
            MapModule.setCenter(r.lat, r.lon, 16);
          });
        });
        resultsEl.querySelectorAll('.a-add').forEach(btn => {
          btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const r = results.find(x => x.id === btn.dataset.id);
            this.addAttractionToItinerary(trip, r);
          });
        });
      }catch(err){
        console.error(err);
        resultsEl.innerHTML = `<p class="muted small">Search failed — the OSM service may be busy. Try again.</p>`;
      }
    };
    document.getElementById('attraction-search-btn').onclick = doSearch;
    document.getElementById('attraction-search').onkeydown = (e) => { if(e.key === 'Enter') doSearch(); };
  },

  addAttractionToItinerary(trip, item){
    if(!trip.days.length){
      trip.days.push({id: uid('day'), date:'', label:'Day 1', items:[]});
    }
    const day = trip.days[0];
    day.items.push({id: uid('item'), dayId: day.id, title:item.name, time:'', desc:`${item.type} · added from map`, lat:item.lat, lon:item.lon});
    Store.save(trip);
    Toast.show(`Added "${item.name}" to ${day.label || 'Day 1'}`);
  },

  /* ================= BUDGET ================= */
  renderBudget(){
    const trip = this.getCurrentTrip();
    if(!trip) return this.route('trips');
    const total = trip.expenses.reduce((a,e)=>a+Number(e.amount||0),0);
    const perPerson = trip.travelers.length ? total / trip.travelers.length : 0;

    document.getElementById('budget-stats').innerHTML = `
      <div class="stat-card"><div class="num">${money(total, trip.currency)}</div><div class="label">Total spent</div></div>
      <div class="stat-card"><div class="num">${trip.expenses.length}</div><div class="label">Expenses logged</div></div>
      <div class="stat-card"><div class="num">${money(perPerson, trip.currency)}</div><div class="label">Avg / traveler</div></div>
    `;

    const list = document.getElementById('expense-list');
    if(!trip.expenses.length){
      list.innerHTML = `<div class="empty-state"><p>No expenses yet. Add one to start splitting costs.</p></div>`;
    }else{
      list.innerHTML = trip.expenses.slice().reverse().map(e => {
        const payer = trip.travelers.find(t => t.id === e.paidBy);
        const splitNames = e.splitWith.map(id => trip.travelers.find(t=>t.id===id)?.name).filter(Boolean);
        return `
        <div class="expense-item">
          <div class="e-info">
            <div class="e-cat">${esc(e.category)}</div>
            <div class="e-title">${esc(e.title)}</div>
            <div class="e-sub">Paid by ${esc(payer ? payer.name : '—')} · split ${splitNames.length} way${splitNames.length!==1?'s':''}</div>
          </div>
          <div class="e-amt">${money(Number(e.amount), trip.currency)}</div>
          <button class="e-del" data-id="${e.id}" title="Delete">🗑</button>
        </div>`;
      }).join('');
      list.querySelectorAll('.e-del').forEach(btn => {
        btn.addEventListener('click', () => {
          trip.expenses = trip.expenses.filter(e => e.id !== btn.dataset.id);
          Store.save(trip);
          this.renderBudget();
        });
      });
    }

    document.getElementById('settle-list').innerHTML = this.computeSettlements(trip);
    document.getElementById('budget-add-expense').onclick = () => this.openExpenseForm(trip);
  },

  computeSettlements(trip){
    if(!trip.expenses.length || trip.travelers.length < 2){
      return `<div class="empty-state"><p>Add expenses with 2+ travelers to see balances.</p></div>`;
    }
    const balances = {};
    trip.travelers.forEach(t => balances[t.id] = 0);

    trip.expenses.forEach(e => {
      const amount = Number(e.amount) || 0;
      const splitWith = e.splitWith.length ? e.splitWith : trip.travelers.map(t=>t.id);
      const share = amount / splitWith.length;
      balances[e.paidBy] = (balances[e.paidBy] || 0) + amount;
      splitWith.forEach(id => { balances[id] = (balances[id] || 0) - share; });
    });

    // simplify debts: greedy match creditors/debtors
    const creditors = [], debtors = [];
    Object.entries(balances).forEach(([id, bal]) => {
      if(bal > 0.005) creditors.push({id, amt: bal});
      else if(bal < -0.005) debtors.push({id, amt: -bal});
    });
    const txns = [];
    let i=0, j=0;
    creditors.sort((a,b)=>b.amt-a.amt); debtors.sort((a,b)=>b.amt-a.amt);
    while(i < debtors.length && j < creditors.length){
      const pay = Math.min(debtors[i].amt, creditors[j].amt);
      txns.push({from: debtors[i].id, to: creditors[j].id, amt: pay});
      debtors[i].amt -= pay; creditors[j].amt -= pay;
      if(debtors[i].amt < 0.01) i++;
      if(creditors[j].amt < 0.01) j++;
    }

    if(!txns.length){
      return `<div class="empty-state"><p>Everyone is settled up! 🎉</p></div>`;
    }
    const nameOf = (id) => trip.travelers.find(t=>t.id===id)?.name || '—';
    return txns.map(tx => `
      <div class="settle-row">💸 <b>${esc(nameOf(tx.from))}</b> owes <b>${esc(nameOf(tx.to))}</b> ${money(tx.amt, trip.currency)}</div>
    `).join('');
  },

  openExpenseForm(trip){
    Modal.open(`
      <h2>Add expense</h2>
      <form id="exp-form">
        <div class="field"><label>Title</label><input required id="e-title" placeholder="Hotel deposit"></div>
        <div class="field-row">
          <div class="field"><label>Amount (${trip.currency})</label><input required type="number" step="0.01" min="0" id="e-amount" placeholder="0.00"></div>
          <div class="field"><label>Category</label>
            <select id="e-category">
              ${['Lodging','Food','Transport','Activities','Shopping','Other'].map(c=>`<option>${c}</option>`).join('')}
            </select>
          </div>
        </div>
        <div class="field"><label>Paid by</label>
          <select id="e-paidby">${trip.travelers.map(t=>`<option value="${t.id}">${esc(t.name)}</option>`).join('')}</select>
        </div>
        <div class="field"><label>Split between</label>
          ${trip.travelers.map(t => `
            <div class="checkbox-row"><input type="checkbox" class="split-cb" value="${t.id}" checked id="cb-${t.id}"><label for="cb-${t.id}">${esc(t.name)}</label></div>
          `).join('')}
        </div>
        <div class="modal-actions">
          <button type="button" class="btn btn-ghost" id="exp-cancel">Cancel</button>
          <button type="submit" class="btn btn-primary">Add expense</button>
        </div>
      </form>
    `, (el) => {
      el.querySelector('#exp-cancel').addEventListener('click', () => Modal.close());
      el.querySelector('#exp-form').addEventListener('submit', (e) => {
        e.preventDefault();
        const title = el.querySelector('#e-title').value.trim();
        const amount = parseFloat(el.querySelector('#e-amount').value);
        if(!title || isNaN(amount) || amount <= 0) return;
        const category = el.querySelector('#e-category').value;
        const paidBy = el.querySelector('#e-paidby').value;
        const splitWith = Array.from(el.querySelectorAll('.split-cb:checked')).map(cb => cb.value);
        trip.expenses.push({id: uid('exp'), title, amount, category, paidBy, splitWith});
        Store.save(trip);
        Modal.close();
        this.renderBudget();
        Toast.show('Expense added');
      });
    });
  },

  /* ================= PACKING ================= */
  renderPacking(){
    const trip = this.getCurrentTrip();
    if(!trip) return this.route('trips');
    const list = document.getElementById('packing-list');
    list.innerHTML = trip.packing.map(p => `
      <li class="${p.checked?'checked':''}" data-id="${p.id}">
        <input type="checkbox" ${p.checked?'checked':''} class="p-check" data-id="${p.id}">
        <span class="p-text">${esc(p.text)}</span>
        <button class="p-del" data-id="${p.id}">🗑</button>
      </li>`).join('') || `<div class="empty-state"><p>List is empty — add items above.</p></div>`;

    const total = trip.packing.length;
    const done = trip.packing.filter(p=>p.checked).length;
    document.getElementById('packing-progress-bar').style.width = total ? `${(done/total)*100}%` : '0%';

    list.querySelectorAll('.p-check').forEach(cb => {
      cb.addEventListener('change', () => {
        const item = trip.packing.find(p => p.id === cb.dataset.id);
        item.checked = cb.checked;
        Store.save(trip);
        this.renderPacking();
      });
    });
    list.querySelectorAll('.p-del').forEach(btn => {
      btn.addEventListener('click', () => {
        trip.packing = trip.packing.filter(p => p.id !== btn.dataset.id);
        Store.save(trip);
        this.renderPacking();
      });
    });

    const addItem = () => {
      const input = document.getElementById('packing-input');
      const text = input.value.trim();
      if(!text) return;
      trip.packing.push({id: uid('pack'), text, checked:false});
      Store.save(trip);
      input.value = '';
      this.renderPacking();
    };
    document.getElementById('packing-add-btn').onclick = addItem;
    document.getElementById('packing-input').onkeydown = (e) => { if(e.key === 'Enter') addItem(); };

    document.getElementById('packing-suggest').onclick = () => {
      const suggestions = ['Sunglasses','Power adapter','Reusable water bottle','Travel pillow','Daypack','Rain jacket','Swimsuit','Camera','Snacks for the flight','Laundry bag'];
      const existingTexts = new Set(trip.packing.map(p=>p.text.toLowerCase()));
      let added = 0;
      suggestions.forEach(s => {
        if(!existingTexts.has(s.toLowerCase())){
          trip.packing.push({id: uid('pack'), text:s, checked:false});
          added++;
        }
      });
      Store.save(trip);
      this.renderPacking();
      Toast.show(added ? `Added ${added} suggested items` : 'Already fully stocked!');
    };
  },

  /* ================= WEATHER ================= */
  async renderWeather(){
    const trip = this.getCurrentTrip();
    if(!trip) return this.route('trips');
    const el = document.getElementById('weather-cards');
    if(!trip.lat || !trip.lon){
      el.innerHTML = `<div class="empty-state"><p>No coordinates found for this destination. Edit the trip to re-locate it.</p></div>`;
      return;
    }
    el.innerHTML = `<p class="muted small">Loading forecast…</p>`;
    try{
      const days = await WeatherModule.forecast(trip.lat, trip.lon);
      el.innerHTML = days.map(d => `
        <div class="weather-card">
          <div class="w-day">${fmtDateShort(d.date)}</div>
          <div class="w-icon">${WeatherModule.describe(d.code).split(' ')[0]}</div>
          <div class="w-temp">${Math.round(d.max)}°</div>
          <div class="w-range">${Math.round(d.min)}° – ${Math.round(d.max)}°</div>
        </div>`).join('');
    }catch(err){
      console.error(err);
      el.innerHTML = `<div class="empty-state"><p>Could not load weather right now. Please try again later.</p></div>`;
    }
  },

  /* ================= CURRENCY ================= */
  async renderCurrency(){
    const trip = this.getCurrentTrip();
    const fromSel = document.getElementById('cur-from');
    const toSel = document.getElementById('cur-to');
    if(!fromSel.options.length){
      fromSel.innerHTML = CurrencyModule.COMMON.map(c => `<option value="${c}">${c}</option>`).join('');
      toSel.innerHTML = CurrencyModule.COMMON.map(c => `<option value="${c}">${c}</option>`).join('');
      fromSel.value = 'USD';
      toSel.value = trip && trip.currency ? trip.currency : 'EUR';
    }

    const compute = async () => {
      const amount = parseFloat(document.getElementById('cur-amount').value) || 0;
      const from = fromSel.value, to = toSel.value;
      document.getElementById('cur-result').textContent = '…';
      try{
        const res = await CurrencyModule.convert(amount, from, to);
        document.getElementById('cur-result').textContent = `${money(res.value, to)}`;
        document.getElementById('cur-meta').textContent = from === to
          ? 'Same currency'
          : `1 ${from} = ${(res.rate).toFixed(4)} ${to} · rates from frankfurter.app, ${res.date}`;
      }catch(err){
        document.getElementById('cur-result').textContent = '—';
        document.getElementById('cur-meta').textContent = 'Could not load exchange rate. Try again.';
      }
    };

    document.getElementById('cur-amount').oninput = debounce(compute, 350);
    fromSel.onchange = compute;
    toSel.onchange = compute;
    document.getElementById('cur-swap').onclick = () => {
      const tmp = fromSel.value; fromSel.value = toSel.value; toSel.value = tmp;
      compute();
    };
    compute();
  }
};

document.addEventListener('DOMContentLoaded', () => App.init());
