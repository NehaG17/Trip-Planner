/* =========================================================
   storage.js — localStorage persistence layer
   ========================================================= */
const DB_KEY = 'waypoint_trips_v1';
const THEME_KEY = 'waypoint_theme';

const Store = {
  _read(){
    try{
      const raw = localStorage.getItem(DB_KEY);
      return raw ? JSON.parse(raw) : [];
    }catch(e){
      console.error('Storage read failed', e);
      return [];
    }
  },
  _write(trips){
    try{
      localStorage.setItem(DB_KEY, JSON.stringify(trips));
    }catch(e){
      console.error('Storage write failed', e);
      Toast.show('Could not save — storage may be full.');
    }
  },
  getAll(){ return this._read(); },
  get(id){ return this._read().find(t => t.id === id) || null; },
  save(trip){
    const trips = this._read();
    const i = trips.findIndex(t => t.id === trip.id);
    if(i > -1) trips[i] = trip; else trips.push(trip);
    this._write(trips);
    return trip;
  },
  remove(id){
    const trips = this._read().filter(t => t.id !== id);
    this._write(trips);
  },
  getTheme(){ return localStorage.getItem(THEME_KEY) || 'dark'; },
  setTheme(t){ localStorage.setItem(THEME_KEY, t); }
};

function uid(prefix='id'){
  return prefix + '_' + Math.random().toString(36).slice(2,9) + Date.now().toString(36).slice(-4);
}

function newTrip({name, destination, lat, lon, startDate, endDate}){
  return {
    id: uid('trip'),
    name, destination, lat, lon, startDate, endDate,
    currency: 'USD',
    travelers: [{id: uid('trav'), name: 'Me'}],
    days: [],
    expenses: [],
    packing: defaultPackingList(),
    notes: '',
    createdAt: Date.now()
  };
}

function defaultPackingList(){
  return [
    'Passport / ID', 'Travel insurance docs', 'Phone charger', 'Toiletries',
    'Medication', 'Comfortable shoes'
  ].map(text => ({id: uid('pack'), text, checked:false}));
}
