/* =========================================================
   util.js — small shared helpers
   ========================================================= */
const Toast = {
  show(msg, ms=3000){
    const stack = document.getElementById('toast-stack');
    const el = document.createElement('div');
    el.className = 'toast';
    el.textContent = msg;
    stack.appendChild(el);
    setTimeout(() => el.remove(), ms);
  }
};

function fmtDate(d){
  if(!d) return '—';
  const date = new Date(d + 'T00:00:00');
  if(isNaN(date)) return d;
  return date.toLocaleDateString(undefined, {month:'short', day:'numeric', year:'numeric'});
}
function fmtDateShort(d){
  const date = new Date(d + 'T00:00:00');
  if(isNaN(date)) return d;
  return date.toLocaleDateString(undefined, {weekday:'short', month:'short', day:'numeric'});
}
function dateRange(start, end){
  if(!start && !end) return 'Dates TBD';
  return `${fmtDate(start)} → ${fmtDate(end)}`;
}
function daysBetween(start, end){
  if(!start || !end) return [];
  const out = [];
  let cur = new Date(start + 'T00:00:00');
  const last = new Date(end + 'T00:00:00');
  while(cur <= last){
    out.push(cur.toISOString().slice(0,10));
    cur.setDate(cur.getDate()+1);
  }
  return out;
}
function tripDaysCount(trip){
  if(!trip.startDate || !trip.endDate) return trip.days.length;
  return daysBetween(trip.startDate, trip.endDate).length;
}
function esc(str=''){
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}
function initials(name=''){
  return name.trim().split(/\s+/).map(p=>p[0]).slice(0,2).join('').toUpperCase() || '?';
}
function money(amount, currency='USD'){
  try{
    return new Intl.NumberFormat(undefined, {style:'currency', currency}).format(amount);
  }catch(e){
    return `${currency} ${amount.toFixed(2)}`;
  }
}
function debounce(fn, ms=400){
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(()=>fn(...args), ms); };
}
